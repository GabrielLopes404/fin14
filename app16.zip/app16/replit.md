# PetsGo - Mobile App for Pet Services

## Overview

PetsGo is a premium mobile application for iOS and Android that connects pet owners with local pet services and products. Built with React Native and Expo, it features a modern, fluid UI inspired by leading food delivery apps but tailored specifically for the pet services industry. The app provides a comprehensive marketplace for pet grooming, veterinary clinics, pet shops, pharmacies, walking services, training, and emergency care.

The application emphasizes a premium user experience through cinematic animations, sophisticated design patterns, and smooth microinteractions powered by React Native Reanimated.

## Recent Changes (November 2025)

**Design System Modernization (November 11, 2025)**
- 🎨 **NOVO DESIGN SYSTEM**: Paleta harmônica sem gradientes baseada em boas práticas 2025
  - Primary: #2563EB (azul moderno e profissional)
  - Accent: #FB923C (coral vibrante para CTAs)
  - Secondary: #10B981 (verde para sucesso)
  - Neutral: Escala de cinzas profissional (#F8FAFC → #1E293B)
  - Cores semânticas (success, error, warning, info)
- ✅ **COMPONENTES ATUALIZADOS**: 8+ componentes críticos convertidos para design flat
  - HeroSection, BannerCarousel, SearchBarPremium
  - PersonalizedHero, FloatingActionDock
  - CategoryIconRow, EmergencyVetSection
  - AnimatedGradient (renomeado para AnimatedComponent)
- 🎯 **ARQUITETURA**: Sistema de design consistente e escalável
  - Regra 60-30-10 para distribuição de cores
  - Overlays sólidos ao invés de gradientes
  - Shadows suaves para profundidade
  - Tokens de design centralizados em `constants/theme.js`
- ✅ **QUALIDADE**: Código revisado e aprovado pelo arquiteto
  - Sem erros no console do navegador
  - Sem dependências de gradientes nos componentes críticos
  - Design responsivo mantido
  - Performance otimizada

**Backend Infrastructure Created (November 10, 2025)**
- ✅ **PostgreSQL Database**: Schema completo com 20+ tabelas para dados reais
  - Usuários, pets, lojas, produtos, serviços
  - Carrinho, pedidos, favoritos, endereços
  - Avaliações, agendamentos, notificações
  - Cupons, métodos de pagamento, tracking
- ✅ **API REST Completa**: Backend Node.js/Express com 50+ endpoints
  - Autenticação JWT (login, signup, forgot-password)
  - CRUD completo para todos os recursos
  - Middleware de autenticação
  - Validação de dados com express-validator
  - Cálculo de distância geográfica
  - Sistema de cupons e descontos
- ✅ **Estrutura Profissional**: Arquitetura escalável
  - Rotas organizadas por recurso
  - Middleware de autenticação
  - Utilitários reutilizáveis
  - Schema SQL com índices otimizados
  - Triggers para atualização automática
  - Dados seed para inicialização

**Premium Onboarding Redesign & Code Cleanup (November 10, 2025)**
- ✨ **NOVO**: Telas de introdução completamente renovadas com design premium e comercial
  - Slide 1: Boas-vindas com mascote estilizado e visual moderno
  - Slide 2: Cards de benefícios animados em grid responsivo
  - Slide 3: CTA poderoso com badge de oferta (10% OFF)
  - Animações cinematográficas e partículas flutuantes
  - Gradientes animados e transições suaves
  - Design responsivo otimizado para todos os tamanhos de tela
- 🧹 **LIMPEZA**: Removidos arquivos backup desnecessários (index.js.backup, .problem, .full)
- 📝 **DOCUMENTAÇÃO**: Adicionados comentários explicativos em componentes complexos
- 🎨 **PADRONIZAÇÃO**: Melhorias na estrutura e consistência visual
- ✅ Código limpo, organizado e bem documentado

**Replit Environment Setup & New Pages (November 10, 2025)**
- Configured project to run on Replit with port 5000 and proper host settings
- Created complete set of profile navigation pages:
  - Personal Data (`/personal-data`) - User profile editing with pet management
  - Addresses (`/addresses`) - Saved addresses management
  - Payment Methods (`/payment-methods`) - Credit card management
  - Notifications (`/notifications`) - Real-time notifications center
  - Notification Settings (`/notification-settings`) - Notification preferences
  - Help Center (`/help-center`) - Customer support hub
  - FAQ (`/faq`) - Frequently asked questions with expandable answers
  - Privacy & Security (`/privacy-security`) - Account security and privacy settings
  - Terms of Use (`/terms`) - Legal terms and conditions
- Updated Profile page to navigate to all new pages
- Added proper .gitignore for Node.js and Expo projects
- Configured workflow for web deployment

**Mobile Optimization Updates**
- Optimized Orders page with improved card layout and compact spacing for mobile screens
- Enhanced Favorites page with responsive grid layout and adaptive filters
- Improved Order Detail page with reduced padding and optimized component sizes for small screens
- Updated StoreCardCompact component with dynamic sizing based on screen width
- All pages now fully optimized for mobile screens, including devices < 360px width
- Removed unused dependencies and cleaned up imports

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture (NEW!)

**Node.js/Express API Server**
- **Port**: 3001 (localhost only, internal backend)
- **Authentication**: JWT tokens with bcryptjs password hashing
- **Database**: PostgreSQL with pg driver
- **Validation**: express-validator for request validation
- **CORS**: Enabled for frontend communication

**Database Schema (PostgreSQL)**
- **users**: User accounts with authentication
- **user_pets**: Pets belonging to users
- **stores**: Pet shops and service providers
- **products**: Products sold by stores
- **services**: Services offered by stores
- **cart_items**: Shopping cart persistence
- **orders**: Order history and tracking
- **order_items**: Items in each order
- **order_tracking**: Real-time order status updates
- **favorites**: User favorite stores
- **addresses**: User saved addresses
- **payment_methods**: Saved payment methods
- **reviews**: Store and product reviews
- **bookings**: Service appointments
- **notifications**: User notifications
- **notification_settings**: Notification preferences
- **coupons**: Discount coupons
- **banners**: Promotional banners

**API Endpoints**
- `/api/auth/*` - Authentication (login, signup, forgot-password)
- `/api/stores/*` - Store listing and details
- `/api/products/*` - Product catalog
- `/api/services/*` - Services catalog
- `/api/cart/*` - Shopping cart management
- `/api/orders/*` - Order creation and tracking
- `/api/favorites/*` - Favorites management
- `/api/addresses/*` - Address management
- `/api/payment-methods/*` - Payment methods
- `/api/notifications/*` - Notifications and settings
- `/api/reviews/*` - Reviews and ratings
- `/api/bookings/*` - Service bookings
- `/api/coupons/*` - Coupon validation
- `/api/profile/*` - User profile and pets

### Frontend Architecture

**Framework & Navigation**
- **React Native (0.81.5) with Expo (~54.0.23)**: Cross-platform mobile development framework enabling iOS and Android deployment from a single codebase
- **Expo Router (^6.0.14)**: File-based routing system providing declarative navigation with Stack and Tabs patterns
- **React Navigation**: Bottom tabs for main sections (Home, Orders, Favorites, Profile) with stack navigation for detailed flows

**Animation System**
- **React Native Reanimated (^4.1.3)**: High-performance animations running on native thread for smooth 60fps experiences
- **React Native Gesture Handler (^2.29.1)**: Native touch gesture recognition for swipe, press, and pull-to-refresh interactions
- **React Native Worklets (^0.6.1)**: JavaScript code execution on UI thread for zero-lag animations
- Shared animation components (PressableScale, AnimatedGradient) for consistent microinteractions across the app

**UI Component System**
- Atomic design methodology with reusable components (Button, Input, Card, Badge, SkeletonLoader)
- Custom components for domain-specific needs (StoreCard, ProductCard, CategoryCard)
- Centralized theme system with design tokens (Colors, Spacing, FontSizes, BorderRadius, Shadows)
- Consistent visual language: no gradients, flat modern design with subtle shadows for depth

**Design Tokens & Theme (Updated November 11, 2025)**
- **Primary color**: #2563EB (modern blue, 60% usage)
- **Accent color**: #FB923C (vibrant coral, 30% usage)
- **Secondary color**: #10B981 (emerald green, 10% usage)
- **Neutral scale**: #F8FAFC → #1E293B (professional grays)
- **Semantic colors**: 
  - Success: #10B981, Error: #EF4444, Warning: #F59E0B, Info: #3B82F6
- **Background system**: 
  - backgroundPrimary: #FFFFFF, backgroundSecondary: #F8FAFC, backgroundCard: #FFFFFF
- **Typography hierarchy**: Professional font sizes and weights
- **Shadow system**: xs, small, medium, large for subtle depth
- **Design Philosophy**: Flat design without gradients, solid colors with overlays

### Application Structure

**Routing Architecture**
- File-based routing with Expo Router following Next.js patterns
- Root layout (`app/_layout.js`) wraps entire app with GestureHandler and StatusBar
- Route groups for logical separation:
  - `(onboarding)`: Intro, Login, Signup, Forgot Password
  - `(tabs)`: Main app sections (Home, Orders, Favorites, Profile)
  - Standalone routes: Store details, Cart, Checkout, Booking

**Screen Categories**

*Authentication & Onboarding*
- Animated intro slides showcasing app features
- User registration with validation
- Social login support
- Password recovery flow

*Core Features*
- **Home**: Location-based store discovery, category browsing, featured stores with ratings and distance
- **Store Details**: Tabbed interface (Products, Services, Reviews, Info) with hero images
- **Shopping Cart**: Item management with quantity controls and price calculation
- **Booking**: Interactive calendar and time slot selection for service appointments
- **Checkout**: Multi-step flow with address selection, payment method, and order summary
- **Notifications**: Real-time notification center with read/unread status
- **Personal Data**: User profile management with pet information
- **Addresses**: Multiple address management with default selection
- **Payment Methods**: Secure credit card management
- **Help Center**: Multi-channel customer support (chat, phone, email, WhatsApp)
- **FAQ**: Organized frequently asked questions by category
- **Notification Settings**: Granular notification preferences
- **Privacy & Security**: Account security with biometric and 2FA options
- **Terms of Use**: Legal documentation and user agreements
- **Orders**: Historical order tracking with status badges
- **Favorites**: Quick access to saved stores
- **Profile**: User settings, addresses, payment methods, support access

**State Management**
- Local component state using React hooks (useState)
- API integration with fetch/axios for backend communication
- JWT token storage for authentication
- Context API for global user state (planned)

**Data Layer**
- **Backend API**: RESTful API with JWT authentication
- **PostgreSQL Database**: Persistent storage for all data
- **Real-time Updates**: Order tracking and notifications
- Mock data constants (`constants/mockData.js`) for development fallback

### External Dependencies

**Core Framework Dependencies**
- **Expo SDK (~54.0.23)**: Managed workflow for React Native development
- **React (19.1.0)**: UI library
- **React Native (0.81.5)**: Mobile framework
- **React DOM (^19.1.0)**: Web compatibility layer

**Backend Dependencies**
- **Express (^4.21.2)**: Web framework for Node.js
- **pg (^8.13.1)**: PostgreSQL client
- **jsonwebtoken (^9.0.2)**: JWT authentication
- **bcryptjs (^2.4.3)**: Password hashing
- **express-validator (^7.2.0)**: Request validation
- **cors (^2.8.5)**: Cross-origin resource sharing
- **dotenv (^16.4.7)**: Environment variables

**Navigation & Routing**
- **expo-router (^6.0.14)**: File-based routing
- **expo-linking (^8.0.8)**: Deep linking support
- **react-native-safe-area-context (^5.6.2)**: Safe area handling for notched devices

**Animation & Gestures**
- **react-native-reanimated (^4.1.3)**: Performant animations
- **react-native-gesture-handler (^2.29.1)**: Native gesture recognition
- **react-native-worklets (^0.6.1)**: UI thread JavaScript execution

**UI Components & Styling**
- **@expo/vector-icons (^15.0.3)**: Icon library (Ionicons)
- **expo-linear-gradient (^15.0.7)**: Gradient rendering
- **expo-font (^14.0.9)**: Custom font loading
- **expo-status-bar (~3.0.8)**: Status bar configuration

**Platform Support**
- **react-native-web (^0.19.13)**: Web platform compatibility (configured for port 5000)

**Build Tools**
- **@babel/core (^7.25.2)**: JavaScript compiler
- **babel-preset-expo (^54.0.7)**: Expo-specific Babel configuration
- **react-native-reanimated/plugin**: Babel plugin for Reanimated worklets

**Configuration**
- Metro bundler with default Expo configuration
- Expo new architecture enabled for improved performance
- Deep linking scheme: `petsgo://`
- Edge-to-edge display for Android
- Adaptive icons and splash screens configured

**Current Integration Status**
- ✅ **Backend API**: Fully implemented and ready to use
- ✅ **Database**: Schema created with seed data
- ✅ **Authentication**: JWT-based authentication system
- 🔄 **Frontend Integration**: Ready to connect to API
- ⏳ **Payment Gateway**: Planned (Stripe integration)
- ⏳ **Push Notifications**: Planned (Expo Notifications)
- ⏳ **Geolocation**: Planned (real distance calculation)
- ⏳ **Image Upload**: Planned (CDN integration)
- ⏳ **Real-time Tracking**: Planned (WebSockets)

**Next Steps for Full Functionality**
1. Connect frontend components to backend API endpoints
2. Implement Stripe payment integration
3. Add Expo Push Notifications
4. Integrate real geolocation services
5. Set up image upload with CDN
6. Implement real-time order tracking
7. Add admin dashboard for store owners
