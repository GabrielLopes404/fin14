import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';
import { orders } from '../../constants/mockData';

function OrderCard({ order }) {
  const router = useRouter();
  
  const getStatusConfig = (status) => {
    switch (status) {
      case 'delivered':
        return { 
          text: 'Entregue', 
          variant: 'success',
          gradient: ['#10B981', '#059669'],
          icon: 'checkmark-circle'
        };
      case 'in_progress':
        return { 
          text: 'Em andamento', 
          variant: 'warning',
          gradient: ['#F59E0B', '#F59E0B'],
          icon: 'time'
        };
      case 'cancelled':
        return { 
          text: 'Cancelado', 
          variant: 'error',
          gradient: ['#EF4444', '#DC2626'],
          icon: 'close-circle'
        };
      default:
        return { 
          text: 'Pendente', 
          variant: 'gray',
          gradient: ['#6B7280', '#4B5563'],
          icon: 'ellipsis-horizontal-circle'
        };
    }
  };

  const statusConfig = getStatusConfig(order.status);

  return (
    <TouchableOpacity
      style={styles.orderCard}
      activeOpacity={0.9}
      onPress={() => router.push(`/orders/${order.id}`)}
    >
      <View style={styles.cardGradient}>
        <View style={styles.orderHeader}>
          <View style={styles.orderHeaderLeft}>
            <View style={[styles.storeIconContainer, { backgroundColor: Colors.primary + '15' }]}>
              <Ionicons name="storefront" size={20} color={Colors.primary} />
            </View>
            <View style={styles.storeInfo}>
              <Text style={styles.storeName} numberOfLines={1}>{order.storeName}</Text>
              <Text style={styles.orderDate}>Pedido #{order.id}</Text>
            </View>
          </View>
          <View style={[styles.statusBadge, { 
            backgroundColor: order.status === 'delivered' ? Colors.success :
                           order.status === 'in_progress' ? Colors.warning :
                           order.status === 'cancelled' ? Colors.error : Colors.textSecondary
          }]}>
            <Text style={styles.statusText}>{statusConfig.text}</Text>
          </View>
        </View>

        <View style={styles.orderDivider} />

        <View style={styles.orderItems}>
          {order.items.slice(0, 2).map((item, index) => (
            <View key={index} style={styles.orderItemRow}>
              <Ionicons name="cube-outline" size={14} color={Colors.textSecondary} />
              <Text style={styles.orderItem} numberOfLines={1}>
                {item.quantity}x {item.name}
              </Text>
            </View>
          ))}
          {order.items.length > 2 && (
            <Text style={styles.moreItems}>
              +{order.items.length - 2} item
            </Text>
          )}
        </View>

        <View style={styles.orderFooter}>
          <View style={styles.dateContainer}>
            <Ionicons name="calendar-outline" size={14} color={Colors.textSecondary} />
            <Text style={styles.footerDate}>{order.date}</Text>
          </View>
          <View style={styles.totalContainer}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.orderTotal}>R$ {order.total.toFixed(2)}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function OrdersScreen() {
  const [filter, setFilter] = useState('all');

  const filters = [
    { id: 'all', name: 'Todos', count: orders.length },
    { id: 'in_progress', name: 'Ativos', count: orders.filter(o => o.status === 'in_progress').length },
    { id: 'delivered', name: 'Entregues', count: orders.filter(o => o.status === 'delivered').length },
  ];

  const filteredOrders = filter === 'all' 
    ? orders 
    : orders.filter(o => o.status === filter);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={[styles.headerGradient, { backgroundColor: Colors.backgroundLight }]}>
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <View style={[styles.headerIcon, { backgroundColor: Colors.primary + '20' }]}>
              <Ionicons name="receipt" size={28} color={Colors.primary} />
            </View>
            <View style={styles.headerTextContainer}>
              <Text style={styles.headerTitle}>Meus Pedidos</Text>
              <Text style={styles.headerSubtitle}>
                {orders.length} {orders.length === 1 ? 'pedido' : 'pedidos'} realizados
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.filtersContainer}>
        {filters.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[
              styles.filterTab,
              filter === item.id && styles.filterTabActive
            ]}
            onPress={() => setFilter(item.id)}
            activeOpacity={0.8}
          >
            <Text style={[
              styles.filterTabText,
              filter === item.id && styles.filterTabTextActive
            ]}>
              {item.name}
            </Text>
            <View style={[
              styles.filterBadge,
              filter === item.id && styles.filterBadgeActive
            ]}>
              <Text style={[
                styles.filterBadgeText,
                filter === item.id && styles.filterBadgeTextActive
              ]}>
                {item.count}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {filteredOrders.length > 0 ? (
          filteredOrders.map((order) => <OrderCard key={order.id} order={order} />)
        ) : (
          <View style={styles.emptyState}>
            <View style={[styles.emptyIconContainer, { backgroundColor: Colors.primary + '10' }]}>
              <Ionicons name="receipt-outline" size={60} color={Colors.primary} />
            </View>
            <Text style={styles.emptyTitle}>Nenhum pedido encontrado</Text>
            <Text style={styles.emptySubtitle}>
              Seus pedidos aparecerão aqui assim que {'\n'}
              você finalizar uma compra
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  headerGradient: {
    paddingBottom: Spacing.lg,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  headerIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.accent + '20',
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.small,
  },
  headerTextContainer: {
    flex: 1,
  },
  headerTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  headerSubtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  filtersContainer: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
  },
  filterTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundLight,
    gap: Spacing.xs,
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  filterTabActive: {
    backgroundColor: Colors.accent + '15',
    borderColor: Colors.accent,
  },
  filterTabText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
  },
  filterTabTextActive: {
    color: Colors.accent,
  },
  filterBadge: {
    backgroundColor: Colors.backgroundGray,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.sm,
    minWidth: 22,
    alignItems: 'center',
  },
  filterBadgeActive: {
    backgroundColor: Colors.accent,
  },
  filterBadgeText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textSecondary,
  },
  filterBadgeTextActive: {
    color: Colors.textLight,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  orderCard: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.md,
    ...Shadows.small,
  },
  cardGradient: {
    padding: Spacing.md,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.sm,
    gap: Spacing.xs,
  },
  orderHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flex: 1,
    minWidth: 0,
  },
  storeIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  storeInfo: {
    flex: 1,
    minWidth: 0,
  },
  storeName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  orderDate: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
  },
  statusBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    flexShrink: 0,
  },
  statusText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  orderDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: Spacing.sm,
  },
  orderItems: {
    gap: 4,
    marginBottom: Spacing.sm,
  },
  orderItemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  orderItem: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    flex: 1,
  },
  moreItems: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
    fontStyle: 'italic',
    marginTop: 2,
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Spacing.xs,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  footerDate: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
  },
  totalContainer: {
    alignItems: 'flex-end',
  },
  totalLabel: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  orderTotal: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xl,
  },
  emptyIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xl,
    ...Shadows.medium,
  },
  emptyTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
});
