import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Platform } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';

const FILTER_CHIPS = [
  { id: 'all', label: 'Todos', icon: 'grid' },
  { id: 'delivery', label: 'Delivery', icon: 'bicycle' },
  { id: 'pickup', label: 'Retirada', icon: 'bag-handle' },
  { id: 'promo', label: 'Promoções', icon: 'pricetag' },
];

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function SearchCommandBar({ 
  onSearch,
  onFilterChange,
  placeholder = 'Buscar produtos, lojas, serviços...',
}) {
  const [activeFilter, setActiveFilter] = useState('all');
  const [isFocused, setIsFocused] = useState(false);
  const focusScale = useSharedValue(1);

  const handleFilterPress = (filterId) => {
    setActiveFilter(filterId);
    onFilterChange?.(filterId);
  };

  const handleFocus = () => {
    setIsFocused(true);
    focusScale.value = withSpring(1.02, Motion.spring.gentle);
  };

  const handleBlur = () => {
    setIsFocused(false);
    focusScale.value = withSpring(1, Motion.spring.gentle);
  };

  const searchBarAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: focusScale.value }],
  }));

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.searchBarContainer, searchBarAnimatedStyle]}>
        {Platform.OS === 'ios' && (
          <BlurView intensity={10} tint="light" style={StyleSheet.absoluteFill} />
        )}
        
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color={Colors.textSecondary} />
          
          <TextInput
            style={styles.searchInput}
            placeholder={placeholder}
            placeholderTextColor={Colors.textSecondary}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onChangeText={onSearch}
          />
          
          {isFocused && (
            <TouchableOpacity activeOpacity={0.7}>
              <Ionicons name="options" size={20} color={Colors.primary} />
            </TouchableOpacity>
          )}
        </View>
      </Animated.View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filtersContainer}
      >
        {FILTER_CHIPS.map((filter) => {
          const isActive = activeFilter === filter.id;
          
          return (
            <FilterChip
              key={filter.id}
              label={filter.label}
              icon={filter.icon}
              isActive={isActive}
              onPress={() => handleFilterPress(filter.id)}
            />
          );
        })}
      </ScrollView>
    </View>
  );
}

function FilterChip({ label, icon, isActive, onPress }) {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.95, Motion.spring.snappy);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, Motion.spring.snappy);
  };

  return (
    <AnimatedTouchable
      style={[
        styles.filterChip,
        isActive && styles.filterChipActive,
        animatedStyle,
      ]}
      activeOpacity={0.9}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <Ionicons 
        name={icon} 
        size={16} 
        color={isActive ? Colors.textLight : Colors.primary} 
      />
      <Text style={[
        styles.filterChipText,
        isActive && styles.filterChipTextActive,
      ]}>
        {label}
      </Text>
    </AnimatedTouchable>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: Spacing.md,
    paddingBottom: Spacing.lg,
    backgroundColor: Colors.background,
  },
  searchBarContainer: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.medium,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.glass.frost,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.8)',
    minHeight: 52,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
    padding: 0,
  },
  filtersContainer: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xl,
    backgroundColor: Colors.primaryLight,
    borderWidth: 1,
    borderColor: Colors.primary + '20',
    gap: Spacing.xs,
    ...Shadows.xs,
  },
  filterChipActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primaryDark,
    ...Shadows.colored,
  },
  filterChipText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
  filterChipTextActive: {
    color: Colors.textLight,
  },
});
