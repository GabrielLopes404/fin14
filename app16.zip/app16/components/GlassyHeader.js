import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';

export default function GlassyHeader({ 
  location = 'Rua das Flores, 123',
  onLocationPress,
  onNotificationPress,
  scrollY = 0,
  hasNotification = true,
}) {
  const animatedScrollY = useSharedValue(0);

  useEffect(() => {
    if (typeof scrollY === 'number') {
      animatedScrollY.value = withSpring(scrollY, Motion.spring.smooth);
    }
  }, [scrollY]);

  const headerAnimatedStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      animatedScrollY.value,
      [0, 60],
      [0.7, 0.95],
      Extrapolate.CLAMP
    );

    const elevation = interpolate(
      animatedScrollY.value,
      [0, 60],
      [0, 8],
      Extrapolate.CLAMP
    );

    return {
      backgroundColor: `rgba(255, 255, 255, ${opacity})`,
      shadowOpacity: elevation / 100,
      shadowRadius: elevation,
      elevation: elevation,
    };
  });

  return (
    <Animated.View style={[styles.container, headerAnimatedStyle]}>
      {Platform.OS === 'ios' && (
        <BlurView intensity={20} tint="light" style={StyleSheet.absoluteFill} />
      )}
      
      <View style={styles.content}>
        <TouchableOpacity 
          style={styles.locationButton} 
          activeOpacity={0.7}
          onPress={onLocationPress}
        >
          <View style={styles.locationIconContainer}>
            <Ionicons name="location" size={18} color={Colors.primary} />
          </View>
          
          <View style={styles.locationTextContainer}>
            <Text style={styles.locationLabel}>Entregar em</Text>
            <Text style={styles.locationText} numberOfLines={1}>
              {location}
            </Text>
          </View>
          
          <Ionicons name="chevron-down" size={18} color={Colors.textSecondary} />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.notificationButton} 
          activeOpacity={0.7}
          onPress={onNotificationPress}
        >
          <Ionicons name="notifications-outline" size={24} color={Colors.textPrimary} />
          {hasNotification && (
            <Animated.View style={styles.notificationBadge}>
              <View style={styles.notificationDot} />
            </Animated.View>
          )}
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(226, 232, 240, 0.5)',
    ...Shadows.small,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    minHeight: 60,
  },
  locationButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.glass.ultraLight,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.8)',
    marginRight: Spacing.md,
    ...Shadows.xs,
  },
  locationIconContainer: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.sm,
  },
  locationTextContainer: {
    flex: 1,
    marginRight: Spacing.sm,
  },
  locationLabel: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  locationText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  notificationButton: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.glass.ultraLight,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.8)',
    ...Shadows.xs,
  },
  notificationBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.backgroundLight,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: Colors.backgroundLight,
  },
  notificationDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.error,
  },
});
