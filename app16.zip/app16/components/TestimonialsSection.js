import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function TestimonialCard({ testimonial }) {
  return (
    <View style={styles.card}>
      <View style={styles.stars}>
        {[...Array(5)].map((_, index) => (
          <Ionicons
            key={index}
            name="star"
            size={16}
            color={index < testimonial.rating ? Colors.rating : Colors.backgroundGray}
          />
        ))}
      </View>
      
      <Text style={styles.text}>{testimonial.text}</Text>
      
      <View style={styles.author}>
        <Image
          source={{ uri: testimonial.avatar }}
          style={styles.avatar}
          resizeMode="cover"
        />
        <View style={styles.authorInfo}>
          <Text style={styles.authorName}>{testimonial.name}</Text>
          <View style={styles.petInfo}>
            <Ionicons name="paw" size={12} color={Colors.primary} />
            <Text style={styles.petName}>{testimonial.petName}</Text>
          </View>
        </View>
        <Ionicons name="checkmark-circle" size={20} color={Colors.success} />
      </View>
    </View>
  );
}

export default function TestimonialsSection({ testimonials = [] }) {
  const defaultTestimonials = [
    {
      id: '1',
      name: 'Maria Silva',
      petName: 'Rex',
      rating: 5,
      text: 'Serviço incrível! Meu cachorro nunca esteve tão feliz. A equipe é super atenciosa e profissional.',
      avatar: 'https://i.pravatar.cc/150?img=1'
    },
    {
      id: '2',
      name: 'João Santos',
      petName: 'Mimi',
      rating: 5,
      text: 'Excelente atendimento! Produtos de qualidade e entrega rápida. Minha gata amou a ração nova.',
      avatar: 'https://i.pravatar.cc/150?img=12'
    },
    {
      id: '3',
      name: 'Ana Costa',
      petName: 'Thor',
      rating: 5,
      text: 'Muito prático e confiável. Agendo os serviços pelo app e sempre sou bem atendida. Recomendo!',
      avatar: 'https://i.pravatar.cc/150?img=5'
    }
  ];

  const displayTestimonials = testimonials.length > 0 ? testimonials : defaultTestimonials;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="heart" size={24} color={Colors.error} />
        <Text style={styles.title}>O que nossos clientes dizem</Text>
      </View>
      <Text style={styles.subtitle}>Mais de 10.000 pets felizes e contentes</Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {displayTestimonials.map((testimonial) => (
          <TestimonialCard key={testimonial.id} testimonial={testimonial} />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
    backgroundColor: Colors.backgroundLight,
    paddingVertical: Spacing.xxxl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  card: {
    width: 300,
    backgroundColor: Colors.background,
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    ...Shadows.medium,
  },
  stars: {
    flexDirection: 'row',
    gap: 4,
    marginBottom: Spacing.md,
  },
  text: {
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    lineHeight: 22,
    marginBottom: Spacing.lg,
  },
  author: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.backgroundGray,
  },
  authorInfo: {
    flex: 1,
  },
  authorName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  petInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  petName: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
});
