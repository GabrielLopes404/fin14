const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { status, limit = 50, offset = 0 } = req.query;

    let query = `
      SELECT 
        b.*,
        s.name as store_name,
        s.image_url as store_image,
        srv.name as service_name,
        p.name as pet_name
      FROM bookings b
      LEFT JOIN stores s ON b.store_id = s.id
      LEFT JOIN services srv ON b.service_id = srv.id
      LEFT JOIN user_pets p ON b.pet_id = p.id
      WHERE b.user_id = $1
    `;
    
    const params = [userId];
    let paramCount = 2;

    if (status) {
      query += ` AND b.status = $${paramCount}`;
      params.push(status);
      paramCount++;
    }

    query += ` 
      ORDER BY b.booking_date DESC, b.booking_time DESC 
      LIMIT $${paramCount} OFFSET $${paramCount + 1}
    `;
    params.push(limit, offset);

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching bookings:', error);
    res.status(500).json({ error: 'Erro ao buscar agendamentos' });
  }
});

router.post('/', async (req, res) => {
  try {
    const userId = req.user.userId;
    const {
      store_id,
      service_id,
      pet_id,
      booking_date,
      booking_time,
      notes
    } = req.body;

    const serviceResult = await db.query(
      'SELECT price FROM services WHERE id = $1',
      [service_id]
    );

    if (serviceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Serviço não encontrado' });
    }

    const totalPrice = serviceResult.rows[0].price;

    const result = await db.query(
      `INSERT INTO bookings (
        user_id, store_id, service_id, pet_id,
        booking_date, booking_time, total_price, notes, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
      RETURNING *`,
      [userId, store_id, service_id, pet_id, booking_date, booking_time, totalPrice, notes]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ error: 'Erro ao criar agendamento' });
  }
});

router.patch('/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;
    const { status } = req.body;

    const result = await db.query(
      `UPDATE bookings 
       SET status = $1, updated_at = NOW()
       WHERE id = $2 AND user_id = $3
       RETURNING *`,
      [status, id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Agendamento não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating booking:', error);
    res.status(500).json({ error: 'Erro ao atualizar agendamento' });
  }
});

module.exports = router;
