const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { hashPassword } = require('../utils/password');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await db.query(
      'SELECT id, name, email, phone, cpf, birth_date, avatar_url, loyalty_points, created_at FROM users WHERE id = $1',
      [userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ error: 'Erro ao buscar perfil' });
  }
});

router.patch('/', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { name, phone, cpf, birth_date, avatar_url } = req.body;

    const fields = [];
    const values = [];
    let paramCount = 1;

    if (name !== undefined) {
      fields.push(`name = $${paramCount}`);
      values.push(name);
      paramCount++;
    }
    if (phone !== undefined) {
      fields.push(`phone = $${paramCount}`);
      values.push(phone);
      paramCount++;
    }
    if (cpf !== undefined) {
      fields.push(`cpf = $${paramCount}`);
      values.push(cpf);
      paramCount++;
    }
    if (birth_date !== undefined) {
      fields.push(`birth_date = $${paramCount}`);
      values.push(birth_date);
      paramCount++;
    }
    if (avatar_url !== undefined) {
      fields.push(`avatar_url = $${paramCount}`);
      values.push(avatar_url);
      paramCount++;
    }

    if (fields.length === 0) {
      return res.status(400).json({ error: 'Nenhum campo para atualizar' });
    }

    values.push(userId);

    const result = await db.query(
      `UPDATE users 
       SET ${fields.join(', ')}, updated_at = NOW() 
       WHERE id = $${paramCount} 
       RETURNING id, name, email, phone, cpf, birth_date, avatar_url, loyalty_points, created_at`,
      values
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ error: 'Erro ao atualizar perfil' });
  }
});

router.get('/pets', async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await db.query(
      'SELECT * FROM user_pets WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching pets:', error);
    res.status(500).json({ error: 'Erro ao buscar pets' });
  }
});

router.post('/pets', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { name, species, breed, birth_date, weight, photo_url } = req.body;

    if (!name || !species) {
      return res.status(400).json({ error: 'Nome e espécie são obrigatórios' });
    }

    const result = await db.query(
      `INSERT INTO user_pets (user_id, name, species, breed, birth_date, weight, photo_url)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [userId, name, species, breed, birth_date, weight, photo_url]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating pet:', error);
    res.status(500).json({ error: 'Erro ao adicionar pet' });
  }
});

router.patch('/pets/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;
    const updates = req.body;

    const fields = [];
    const values = [];
    let paramCount = 1;

    Object.entries(updates).forEach(([key, value]) => {
      if (value !== undefined) {
        fields.push(`${key} = $${paramCount}`);
        values.push(value);
        paramCount++;
      }
    });

    if (fields.length === 0) {
      return res.status(400).json({ error: 'Nenhum campo para atualizar' });
    }

    values.push(id, userId);

    const result = await db.query(
      `UPDATE user_pets 
       SET ${fields.join(', ')} 
       WHERE id = $${paramCount} AND user_id = $${paramCount + 1} 
       RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pet não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating pet:', error);
    res.status(500).json({ error: 'Erro ao atualizar pet' });
  }
});

router.delete('/pets/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM user_pets WHERE id = $1 AND user_id = $2 RETURNING *',
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pet não encontrado' });
    }

    res.json({ message: 'Pet removido' });
  } catch (error) {
    console.error('Error deleting pet:', error);
    res.status(500).json({ error: 'Erro ao remover pet' });
  }
});

module.exports = router;
